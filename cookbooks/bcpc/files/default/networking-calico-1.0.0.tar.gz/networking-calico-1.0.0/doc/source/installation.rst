============
Installation
============

At the command line::

    $ pip install networking-calico

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv networking-calico
    $ pip install networking-calico
